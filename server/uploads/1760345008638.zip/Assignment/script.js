const validEmail = "kishoore@gmail.com";
const validPassword = "jk04";

const form = document.getElementById("loginForm");
const email = document.getElementById("email");
const password = document.getElementById("password");
const emailErr = document.getElementById("emailError");
const passErr = document.getElementById("passwordError");
const feedback = document.getElementById("feedback");

document.getElementById("showPass").addEventListener("change", e => {
  password.type = e.target.checked ? "text" : "password";
});

form.addEventListener("submit", e => {
  e.preventDefault();
  emailErr.textContent = "";
  passErr.textContent = "";
  feedback.textContent = "";

  const emailVal = email.value.trim();
  const passVal = password.value;

  if (!emailVal.match(/^[^@\s]+@[^@\s]+\.[^@\s]+$/)) {
    emailErr.textContent = "Invalid email";
    return;
  }

  if (passVal.length < 4) {
    passErr.textContent = "Too short";
    return;
  }

  if (emailVal === validEmail && passVal === validPassword) {
    feedback.style.color = "green";
    feedback.textContent = "Login successful!";
    setTimeout(() => window.location.href = "index.html", 1000);
  } else {
    feedback.style.color = "red";
    feedback.textContent = "Wrong credentials.";
  }
});
