import React from "react";
import "./index.css";

export default function App() {
  return (
    <div className="app">
      <h1>Hello React App</h1>
      <button className="btn">Click Me</button>
    </div>
  );
}