import React from "react";
import "./index.css";

export default function App() {
  return (
    <View style="app">
      <Text>Hello React App</Text>
      <TouchableOpacity style="btn">Click Me</TouchableOpacity>
    </View>
  );
}